from qsiml.qsiml import QuantumCircuit

qc = QuantumCircuit(2)
qc.h(0)
qc.dump()
